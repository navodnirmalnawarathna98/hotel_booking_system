const categorys = [
  {
    title: "Luxury Room",
    number: 8,
  },
  {
    title: "Small Suite",
    number: 6,
  },
  {
    title: "Single",
    number: 5,
  },
  {
    title: "Family",
    number: 9,
  },
  {
    title: "Double Room",
    number: 3,
  },
  
];

export default categorys;
